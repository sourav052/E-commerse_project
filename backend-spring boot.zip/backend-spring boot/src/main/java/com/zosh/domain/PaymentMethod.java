package com.zosh.domain;

public enum PaymentMethod {
    RAZORPAY,
    STRIPE
}
