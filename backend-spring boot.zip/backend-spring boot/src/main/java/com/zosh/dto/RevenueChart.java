package com.zosh.dto;

import lombok.Data;

@Data
public class RevenueChart {
    private String date;
    private double revenue;
}
