package com.zosh.request;

import lombok.Data;
import lombok.Getter;

@Data
public class Prompt {
    private String prompt;
}
