package com.zosh.ai.services;

import org.springframework.stereotype.Service;

@Service
public class ProductDetailsBotServiceImpl implements ProductDetailsBotService{


    @Override
    public String productDetailsChatBot(String prompt) {
        return "";
    }
}
