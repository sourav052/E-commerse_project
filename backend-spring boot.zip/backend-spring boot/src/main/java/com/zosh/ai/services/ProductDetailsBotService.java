package com.zosh.ai.services;

public interface ProductDetailsBotService {

    String productDetailsChatBot(String prompt);
}
